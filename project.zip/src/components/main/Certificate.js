import{Link} from "react-router-dom";
import { useState } from "react"
import "./Certificate.scss"
import Main from './Main';
import Buttom_Information from './Bottom_Information';

export default function Certificate(){

    return(
        <div>
     <div className="Certificate_container">
        <img id="certificate_Title" src="./certificate_img/Certificate_Title_img.png"/>
        <div className="My_certificate_txt">현재 취득한 자격증</div>
        <div className="Video_img_contaioner">
                <img id="my_Certificate"src="./certificate_img/My_Certificate1.png"></img>
                <img id="my_Certificate"src="./certificate_img/My_Certificate2.png"></img>
        </div>
        <img id="certificate_Title2" src="./certificate_img/Certificate_Title2.png"/>
        <div className="My_certificate_txt">조주기능사 참고 영상</div>
        <img id="certificate_vedio1"src="./certificate_img/Certificate_date_video.png"/>
        <img id="certificate_Title2" src="./certificate_img/Certificate_Title3.png"/>
        <img id="certificate_date"src="./certificate_img/Certificate_date_img.png"></img>
        <button id="exam_notes_button"><b>조주기능사 시험 유의사항 확인 하기</b></button>
     </div>

     </div>

    )
}