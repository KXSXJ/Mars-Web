import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from "react-router-dom"
import Main from './Main';
import Intrucduce from './Intruduce';
import Buttom_Information from './Bottom_Information';
import Certificate from './Certificate';

export default function Home(){
    return(
        <div>
        <Main/>
        </div>
    )
}