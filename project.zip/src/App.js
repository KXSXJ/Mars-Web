
import {
  Routes,
  Route,
  Link
} from "react-router-dom";
import Home from "./components/main";
import Bartendet_Certificate from "./components/main/Certificate";

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home/>} />
      <Route path="/bartender_certificate_page" element={<Bartendet_Certificate/>}/>
    </Routes>
  );
}

export default App;
